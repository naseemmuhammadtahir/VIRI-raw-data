# -*- coding: utf-8 -*-
"""
Created on Thu May 30 10:50:15 2024

@author: Owner
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 13:13:14 2024

@author: Owner
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Jul 21 10:00:14 2023

@author: Owner
"""

import torch
import torch.nn as nn
from torchvision import models
from torchvision import transforms as T
from torchvision.datasets import ImageFolder
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F
import numpy as np
import seaborn as sns

import matplotlib.pyplot as plt
from pathlib import Path
from typing import Tuple
from PIL import Image
from tqdm import tqdm
import torch.optim as optim
from sklearn.svm import SVC
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import ConfusionMatrixDisplay, accuracy_score, recall_score, precision_score, f1_score

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(DEVICE)

dir_train_vis = 'C:/Users/Owner/Desktop/Single-modal- VIRI/Vis/train_aug_images/'
dir_train_ir = 'C:/Users/Owner/Desktop/Single-modal- VIRI/IR/train_aug_images/' 
#dir_train_msx = 'C:/Users/naseem/Desktop/VIRI-dataset&code/MSX/train_aug_images/' 

dir_val_vis = 'C:/Users/Owner/Desktop/Single-modal- VIRI/tran_val_test/Visible/val/'
dir_val_ir = 'C:/Users/Owner/Desktop/Single-modal- VIRI/tran_val_test/IR/val/'
#dir_val_msx = 'C:/Users/naseem/Desktop/VIRI-dataset&code/tran_val_test/MSX/val/'

data_transforms = T.Compose([
    T.PILToTensor(),
    T.ConvertImageDtype(torch.float),
    T.Resize((224,224), antialias=True),
])

class VIRIConcat(Dataset):
  """ dataset for both visible and infrared images,
  the __getitem__ method returns the infrared image, the visible image and their label.
  the infrared and visible images must always correspond, some assertions are added to
  ensure this.
  """
  def __init__(self, visible_imgs_path: str, infrared_imgs_path: str, transforms: T.transforms=None):
    
    self.transforms = transforms
    self.labelmap = {'Angry': 0, 'Happy': 1, 'Neutral': 2, 'Sad': 3, 'Surprise': 4}
    
    self.ir_images = [i for i in Path(infrared_imgs_path).rglob("*.JPG")]
    self.vis_images = [i for i in Path(visible_imgs_path).rglob("*.JPG")]
    #print(self.vis_images)
    
  def __getitem__(self, idx):
    
    res_dict = {}
    ir_path = self.ir_images[idx]
    #print(ir_path)
    ir_img = Image.open(ir_path).convert('RGB')

    vis_path = self.vis_images[idx]
    vis_img = Image.open(vis_path).convert('RGB')

    # label is folder name
    ir_label = ir_path.parent.name
    vis_label = vis_path.parent.name
    #print(vis_label)
    # conver label to number
    
    label_vis = self.labelmap.get(vis_label)
    label_ir = self.labelmap.get(ir_label)
    #print(label_vis)
    #print(label_ir)
    
    if self.transforms:
      ir_img = self.transforms(ir_img)
      vis_img = self.transforms(vis_img)
      
      res_dict['vis'] = [vis_img, label_vis, vis_path.__str__()]
      res_dict['ir'] = [ir_img, label_ir, ir_path.__str__()]

    return res_dict

  def __len__(self):
    return len(self.ir_images)

train_data = VIRIConcat(visible_imgs_path=dir_train_vis, infrared_imgs_path=dir_train_ir, transforms=data_transforms)
val_data = VIRIConcat(visible_imgs_path=dir_val_vis, infrared_imgs_path=dir_val_ir, transforms=data_transforms)

#train_data = VIRIConcat(visible_imgs_path=dir_train_msx, infrared_imgs_path=dir_train_msx, transforms=data_transforms)
#val_data = VIRIConcat(visible_imgs_path=dir_val_vis, infrared_imgs_path=dir_val_msx, transforms=data_transforms)
#print(len(viri_val))

train_loader = DataLoader(train_data, batch_size=64, shuffle=True)
print(len(train_loader))

valid_loader = DataLoader(val_data, batch_size=8, shuffle=False)
print(len(valid_loader))

for ind, (result) in enumerate(valid_loader):
    image_1, label_1, vis_path = result['vis']
    image_2, label_2, ir_path = result['ir']
    print(image_1.shape)
    #print(vis_path)
    print(label_1)
    print(image_2.shape)
    #print(ir_path)
    print(label_2)
    
def train_fn(concat_model, train_loader, optimizer, criterion, device="cuda"):
    concat_model.train()
    training_run_loss = 0.0
    train_running_correct = 0

    m = len(train_loader.dataset)
    for i, data in tqdm(enumerate(train_loader), total=int(m/train_loader.batch_size)):
        image_1, label_1, vis_path = data['vis']
        image_2, label_2, ir_path = data['ir']
        
        image_1 = image_1.to(device)
        label_1 = label_1.to(device)
        
        image_2 = image_2.to(device)
        label_2 = label_2.to(device)

        output = concat_model(image_1, image_2)
        loss = criterion(output, label_1)

        training_run_loss += loss.item()
        _, preds = torch.max(output.data, 1)
        train_running_correct += (preds == label_1).sum().item()

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        del image_1, image_2, label_1, label_2, output, preds
        torch.cuda.empty_cache()

    train_loss = training_run_loss / m
    train_accuracy = train_running_correct / m
    return train_loss, train_accuracy


def validation_fn(model, valid_loader, criterion, device="cuda"):
    model.eval()
    val_running_loss = 0.0
    val_running_correct = 0

    m = len(valid_loader.dataset)
    with torch.no_grad():
        for i,data in tqdm(enumerate(valid_loader), total=int(m/valid_loader.batch_size)):
            image_1, label_1, vis_path = data['vis']
            image_2, label_2, ir_path = data['ir']
            
            image_1 = image_1.to(device)
            label_1 = label_1.to(device)
            
            image_2 = image_2.to(device)
            label_2 = label_2.to(device)

            output = concat_model(image_1, image_2)
            loss = criterion(output, label_1)

            val_running_loss += loss.item()
            _, preds = torch.max(output.data, 1)
            val_running_correct += (preds == label_1).sum().item()

            del image_1, image_2, label_1, label_2, output, preds
            torch.cuda.empty_cache()

        val_loss = val_running_loss / m
        val_accuracy = val_running_correct / m
        return val_loss, val_accuracy


def plot_confusion_matrix(y_t, y_p, cmap=plt.cm.Blues, title="Confusion Matrix",
                          disp_labels=None, normalize: str=None,
            ax=None, cbar=True):
    """ visualize confusion matrix """
    if ax is None:
        fig, ax = plt.subplots(1, 1, figsize=(5, 4))

    # display Confusion Matrix
    ConfusionMatrixDisplay.from_predictions(y_t, y_p, cmap=cmap, ax=ax,
                                            display_labels=disp_labels, colorbar=cbar,
                                            xticks_rotation=45, normalize=normalize);

    plt.title(title)
    plt.xlabel("Prediction")
    plt.ylabel("Actual")


def plot_vals(train_vals: list, valid_vals: list, val: str="Loss"):
    epoch_count = range(1, len(train_vals) + 1)
    fig = plt.figure(figsize=(8,8))
    plt.plot(epoch_count, train_vals, 'g', label=f'training {val}')
    plt.plot(epoch_count, valid_vals, 'b', label=f'validation {val}')
    plt.title(f'Training and Validation {val}')
    plt.xlabel('Epochs')
    plt.ylabel(f'{val}')
    plt.legend()
    return fig    
  
# Define Attention module
class SimpleAttention(nn.Module):
    def __init__(self, in_features, out_features):
        super(SimpleAttention, self).__init__()
        self.fc = nn.Linear(in_features, out_features)

    def forward(self, x):

        attention_weights = torch.sigmoid(self.fc(x*x))

        x = x * attention_weights
        return x

class SimpleResNetWithAttention_IR(nn.Module):
    def __init__(self, num_classes):
        super(SimpleResNetWithAttention_IR, self).__init__()
        self.resnet = models.resnet18(pretrained=True)
        self.resnet = nn.Sequential(*list(self.resnet.children())[:-1])
        
        # Define the attention mechanism
        self.attention = SimpleAttention(512, 512)
        self.fc = nn.Sequential(
            nn.Dropout(0.7),
            nn.Linear(512, 256),  # First Linear layer
            nn.ReLU(),
            nn.BatchNorm1d(256),  # BatchNorm1d added here, after ReLU
            nn.Dropout(0.8),
            nn.Linear(256, 5),  # Output layer
            nn.Softmax(dim=1)   # Make sure to use dim=1 for batch-wise operations
        )   
        

    def forward(self, x, inference=False):
        x = self.resnet(x)

        # Apply attention mechanism
        x = x.view(x.size(0), -1)  # Flatten before attention
        x = self.attention(x)

        # Classification layer
        x = self.fc(x)
        return x

model_ir = SimpleResNetWithAttention_IR(num_classes=5)  
model_ir.load_state_dict(torch.load(r"C:\Users\Owner\Desktop\VIRI-new-paper\IR\trained-weights-ir-with-attention_51.1%\resnet18withattention_19_0.494_weights.pt", map_location=DEVICE))
model_ir.to(DEVICE)

class SimpleResNetWithAttention_Vis(nn.Module):
    def __init__(self, num_classes):
        super(SimpleResNetWithAttention_Vis, self).__init__()
        self.resnet = models.resnet18(pretrained=True)
        self.resnet = nn.Sequential(*list(self.resnet.children())[:-1])
        
        # Define the attention mechanism
        self.attention = SimpleAttention(512, 512)
        self.fc = nn.Sequential(
            nn.Dropout(0.4),
            nn.Linear(512, 256),  # First Linear layer
            #nn.ReLU(),
            #nn.BatchNorm1d(256),  # BatchNorm1d added here, after ReLU
            nn.Dropout(0.4),
            nn.Linear(256, 5),  # Output layer
            nn.Softmax(dim=1)   # Make sure to use dim=1 for batch-wise operations
        )   
        

    def forward(self, x, inference=False):
        x = self.resnet(x)

        # Apply attention mechanism
        x = x.view(x.size(0), -1)  # Flatten before attention
        x = self.attention(x)

        # Classification layer
        x = self.fc(x)
        return x

model_vis = SimpleResNetWithAttention_Vis(num_classes=5)
#model_vis.load_state_dict(torch.load(r"C:\Users\Owner\Desktop\VIRI-new-paper\Vis\trained-weights-with-attention_82.2%\resnet18withattention_3_0.807_weights.pt", map_location=DEVICE))
model_vis.to(DEVICE)
model_name = "combined-vis-ir-attention"

# =============================================================================
# class Combined_model(nn.Module):
#     def __init__(self, modelA, modelB):
#         super(Combined_model, self).__init__()
#         self.modelA = modelA
#         self.modelB = modelB
#         # Remove last linear layer
#         self.modelA.fc = nn.Identity()
#         print(modelA)
#         self.modelB.fc = nn.Identity()
#         print(modelB)
#         self.softmax = nn.Softmax(1)
#         self.fc = nn.Linear(512+512, 5)
#                     
#     def forward(self, x1, x2):
#         x1 = self.modelA(x1)
#         x2 = self.modelB(x2)
#         x = torch.cat((x1, x2), dim=1)
#         x = self.fc(F.relu(x))
#         x = self.softmax(x)
#         return x
# =============================================================================
class Combined_model(nn.Module):
    def __init__(self, modelA, modelB):
        super(Combined_model, self).__init__()
        self.modelA = modelA
        self.modelB = modelB
        # Remove last linear layer
        self.modelA.fc = nn.Identity()
        self.modelB.fc = nn.Identity()
        
        # Number of features from each model
        self.num_featuresA = 512
        self.num_featuresB = 512
        
        # Define the fully connected layers
        self.fc = nn.Sequential(
            nn.Dropout(0.2),
            nn.Linear(self.num_featuresA + self.num_featuresB, 256),  # Interleaved concatenation
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.Dropout(0.2),
            nn.Linear(256, 5),
            nn.Dropout(0.2),
            nn.Softmax(dim=1)   
        )
        
    def forward(self, x1, x2):
        # Get the features from both models
        x1 = self.modelA(x1)
        x2 = self.modelB(x2)
        
        # Interleaved concatenation
        x = torch.stack((x1, x2), dim=2).view(x1.size(0), -1)
        
        # Pass through fully connected layers
        x = self.fc(x)
        return x

# x1 = torch.randn(1, 3, 224, 224)
# x2 = torch.randn(1, 3, 224, 224)

concat_model = Combined_model(model_vis, model_ir)
concat_model.to(DEVICE)

criterion = nn.CrossEntropyLoss()
epochs = 150

lr = 1e-3
optimizer = optim.Adam(concat_model.parameters(), lr=lr)
#lr_scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max', patience=3)
lr_scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=3)
Path("C:/Users/Owner/Desktop/VIRI-new-paper/Vis-IR/weights/").mkdir(exist_ok=True)

train_acc, train_loss = [], []
val_acc, val_loss = [], []
lrs = []
best_acc = 0.0
best_loss = torch.inf

for epoch in range(1, epochs+1):
    print(f"Epoch: {epoch}/{epochs}")

    epoch_lr = optimizer.param_groups[0]["lr"]
    lrs.append(epoch_lr)

    # train for one epoch
    train_loss_ep, train_acc_ep = train_fn(concat_model, train_loader, optimizer, criterion, device=DEVICE)
    val_loss_ep, val_acc_ep = validation_fn(concat_model, valid_loader, criterion, device=DEVICE)
    #lr_scheduler.step(val_acc_ep)
    lr_scheduler.step()
    
    # append train metrics
    train_acc.append(train_acc_ep)
    train_loss.append(train_loss_ep)

    # append val metrics
    val_acc.append(val_acc_ep)
    val_loss.append(val_loss_ep)

    print(f'loss {train_loss_ep:.3f} -acc {train_acc_ep:.3f} - val_loss {val_loss_ep:.3f} -val_acc {val_acc_ep:.3f}')
    if val_acc_ep >= best_acc:
        best_acc = val_acc_ep
        torch.save(concat_model.state_dict(), f'C:/Users/Owner/Desktop/VIRI-new-paper/Vis-IR/weights/{model_name}_{epoch}_{best_acc:.3f}_weights.pt')
        print("=> saved best model")
        torch.cuda.empty_cache()
    
    if epoch == epochs:
      # save model weights at last epoch
      torch.save(concat_model.state_dict(), f'C:/Users/Owner/Desktop/VIRI-new-paper/Vis-IR/weights/{model_name}_last_weights.pt')
      

_ = plot_vals(train_loss, val_loss)
plt.savefig(f"C:/Users/Owner/Desktop/VIRI-new-paper/Vis-IR/weights/{model_name}_losses.jpg")

_ = plot_vals(train_acc, val_acc, val="Accuracy")
plt.savefig(f"C:/Users/Owner/Desktop/VIRI-new-paper/Vis-IR/weights/{model_name}_accuracy.jpg")      